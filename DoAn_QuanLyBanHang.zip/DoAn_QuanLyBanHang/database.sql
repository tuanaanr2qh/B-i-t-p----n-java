CREATE DATABASE QLBanHang;
GO
USE QLBanHang;
GO

CREATE TABLE KhachHang (
    MaKH VARCHAR(15) PRIMARY KEY,
    TenKH NVARCHAR(100) NOT NULL,
    SoDienThoai VARCHAR(15) UNIQUE,
    DiaChi NVARCHAR(200),
    Email VARCHAR(100)
);
GO

CREATE TABLE NhanVien (
    MaNV VARCHAR(15) PRIMARY KEY,
    TenNV NVARCHAR(100) NOT NULL,
    NgaySinh DATE NULL,
    GioiTinh NVARCHAR(10),
    SoDienThoai VARCHAR(15),
    DiaChi NVARCHAR(200)
);
GO

CREATE TABLE SanPham (
    MaSP VARCHAR(15) PRIMARY KEY,
    TenSP NVARCHAR(120) NOT NULL,
    DonViTinh NVARCHAR(30),
    DonGia DECIMAL(18,2) NOT NULL CHECK (DonGia >= 0),
    SoLuongTon INT NOT NULL CHECK (SoLuongTon >= 0)
);
GO

CREATE TABLE HoaDon (
    MaHD VARCHAR(15) PRIMARY KEY,
    NgayLap DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    MaKH VARCHAR(15) NOT NULL,
    MaNV VARCHAR(15) NOT NULL,
    CONSTRAINT FK_HoaDon_KhachHang FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH),
    CONSTRAINT FK_HoaDon_NhanVien FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV)
);
GO

CREATE TABLE ChiTietHoaDon (
    MaHD VARCHAR(15) NOT NULL,
    MaSP VARCHAR(15) NOT NULL,
    SoLuong INT NOT NULL CHECK (SoLuong > 0),
    DonGia DECIMAL(18,2) NOT NULL CHECK (DonGia >= 0),
    ThanhTien AS CAST(SoLuong * DonGia AS DECIMAL(18,2)) PERSISTED,
    CONSTRAINT PK_ChiTietHoaDon PRIMARY KEY (MaHD, MaSP),
    CONSTRAINT FK_CTHD_HoaDon FOREIGN KEY (MaHD) REFERENCES HoaDon(MaHD),
    CONSTRAINT FK_CTHD_SanPham FOREIGN KEY (MaSP) REFERENCES SanPham(MaSP)
);
GO

CREATE VIEW vw_DoanhThuHoaDon AS
SELECT h.MaHD, h.NgayLap, kh.TenKH, nv.TenNV,
       SUM(ct.SoLuong * ct.DonGia) AS TongTien
FROM HoaDon h
JOIN KhachHang kh ON h.MaKH = kh.MaKH
JOIN NhanVien nv ON h.MaNV = nv.MaNV
JOIN ChiTietHoaDon ct ON h.MaHD = ct.MaHD
GROUP BY h.MaHD, h.NgayLap, kh.TenKH, nv.TenNV;
GO

INSERT INTO KhachHang VALUES
('KH001', N'Nguyễn Văn An', '0988111222', N'Hà Nội', 'an@example.com'),
('KH002', N'Trần Thị Bình', '0977222333', N'Quảng Ninh', 'binh@example.com');
INSERT INTO NhanVien(MaNV,TenNV,NgaySinh,GioiTinh,SoDienThoai,DiaChi) VALUES
('NV001',N'Lê Minh Hùng','2002-04-10',N'Nam','0966111222',N'Hà Nội');
INSERT INTO SanPham VALUES
('SP001',N'Bàn phím máy tính',N'Cái',350000,30),
('SP002',N'Chuột máy tính',N'Cái',180000,50),
('SP003',N'Tai nghe',N'Cái',420000,20);
GO
