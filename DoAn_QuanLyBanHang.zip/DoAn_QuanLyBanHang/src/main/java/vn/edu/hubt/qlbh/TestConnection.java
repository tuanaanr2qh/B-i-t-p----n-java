
package vn.edu.hubt.qlbh;

import java.sql.Connection;

public class TestConnection {
    public static void main(String[] args) {
        try {
            Connection conn = DB.getConnection();

            System.out.println("KET NOI THANH CONG!");
            System.out.println("Database: " + conn.getCatalog());

            conn.close();

        } catch (Exception e) {
            System.out.println("KET NOI THAT BAI!");
            System.out.println("NGUYEN NHAN: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
