package vn.edu.hubt.qlbh;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import vn.edu.hubt.qlbh.ui.MainFrame;
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
            new MainFrame().setVisible(true);
        });
    }
}
