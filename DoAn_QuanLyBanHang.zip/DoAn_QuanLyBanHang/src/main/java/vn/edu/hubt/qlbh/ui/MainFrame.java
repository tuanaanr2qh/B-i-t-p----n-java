package vn.edu.hubt.qlbh.ui;

import vn.edu.hubt.qlbh.DB;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.Vector;

public class MainFrame extends JFrame {
    public MainFrame() {
        setTitle("PHẦN MỀM QUẢN LÝ BÁN HÀNG");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1100, 680);
        setLocationRelativeTo(null);
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Sản phẩm", productPanel());
        tabs.addTab("Khách hàng", customerPanel());
        tabs.addTab("Hóa đơn", invoicePanel());
        tabs.addTab("Thống kê doanh thu", revenuePanel());
        add(tabs);
    }

    private JPanel productPanel() {
        String[] cols={"Mã SP","Tên SP","Đơn Vị Tính","Đơn Giá","Số Lượng"};
        JTable table=new JTable(); JTextField[] f=fields(5);
        JPanel p=basePanel(table, new String[]{"Mã SP","Tên SP","Đơn Vị Tính","Đơn Giá","Số Lượng"}, f);
        JButton add=new JButton("Thêm"), update=new JButton("Sửa"), delete=new JButton("Xóa"), reload=new JButton("Tải lại");
        JPanel actions=actions(add,update,delete,reload); p.add(actions,BorderLayout.SOUTH);
        Runnable load=()->load(table,"SELECT MaSP,TenSP,DonViTinh,DonGia,SoLuongTon FROM SanPham",cols);
        table.getSelectionModel().addListSelectionListener(e->{if(!e.getValueIsAdjusting()&&table.getSelectedRow()>=0)for(int i=0;i<f.length;i++)f[i].setText(String.valueOf(table.getValueAt(table.getSelectedRow(),i)));});
        add.addActionListener(e->runSql("INSERT INTO SanPham(MaSP,TenSP,DonViTinh,DonGia,SoLuongTon) VALUES(?,?,?,?,?)",f,load));
        update.addActionListener(e->{try(Connection c=DB.getConnection();PreparedStatement s=c.prepareStatement("UPDATE SanPham SET TenSP=?,DonViTinh=?,DonGia=?,SoLuongTon=? WHERE MaSP=?")){
            s.setString(1,f[1].getText().trim());s.setString(2,f[2].getText().trim());s.setBigDecimal(3,new java.math.BigDecimal(f[3].getText().trim()));s.setInt(4,Integer.parseInt(f[4].getText().trim()));s.setString(5,f[0].getText().trim());s.executeUpdate();load.run();msg("Đã cập nhật sản phẩm");
        }catch(Exception ex){err(ex);}});
        delete.addActionListener(e->{try(Connection c=DB.getConnection();PreparedStatement s=c.prepareStatement("DELETE FROM SanPham WHERE MaSP=?")){s.setString(1,f[0].getText().trim());s.executeUpdate();load.run();msg("Đã xóa sản phẩm");}catch(Exception ex){err(ex);}});
        reload.addActionListener(e->load.run()); load.run(); return p;
    }


private JPanel customerPanel() {
    String[] cols = {
        "Mã KH", "Tên KH", "Số Điện Thoại", "Địa Chỉ", "Email"
    };

    JTable table = new JTable();
    JTextField[] f = fields(5);

    JPanel p = basePanel(table,
        new String[]{"Mã KH", "Tên KH", "Số Điện Thoại", "Địa Chỉ", "Email"},
        f
    );

    JButton add = new JButton("Thêm");
    JButton update = new JButton("Sửa");
    JButton delete = new JButton("Xóa");
    JButton reload = new JButton("Làm mới");

    p.add(actions(add, update, delete, reload), BorderLayout.SOUTH);

    Runnable load = () -> load(
        table,
        "SELECT MaKH, TenKH, SoDienThoai, DiaChi, Email FROM KhachHang",
        cols
    );

    Runnable clear = () -> {
        for (JTextField field : f) {
            field.setText("");
        }
        table.clearSelection();
    };

    table.getSelectionModel().addListSelectionListener(e -> {
        if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
            int row = table.getSelectedRow();

            for (int i = 0; i < f.length; i++) {
                Object value = table.getValueAt(row, i);
                f[i].setText(value == null ? "" : value.toString());
            }
        }
    });

    add.addActionListener(e -> {
        if (f[0].getText().trim().isEmpty()
                || f[1].getText().trim().isEmpty()) {
            msg("Vui lòng nhập Mã khách hàng và Tên khách hàng!");
            return;
        }

        String sql = "INSERT INTO KhachHang "
                + "(MaKH, TenKH, SoDienThoai, DiaChi, Email) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (Connection c = DB.getConnection();
             PreparedStatement s = c.prepareStatement(sql)) {

            for (int i = 0; i < 5; i++) {
                s.setString(i + 1, f[i].getText().trim());
            }

            int result = s.executeUpdate();

            if (result > 0) {
                load.run();
                clear.run();
                msg("Thêm khách hàng thành công!");
            }

        } catch (Exception ex) {
            err(ex);
        }
    });

    update.addActionListener(e -> {
        if (f[0].getText().trim().isEmpty()) {
            msg("Vui lòng chọn khách hàng cần sửa!");
            return;
        }

        String sql = "UPDATE KhachHang SET "
                + "TenKH = ?, SoDienThoai = ?, "
                + "DiaChi = ?, Email = ? "
                + "WHERE MaKH = ?";

        try (Connection c = DB.getConnection();
             PreparedStatement s = c.prepareStatement(sql)) {

            s.setString(1, f[1].getText().trim());
            s.setString(2, f[2].getText().trim());
            s.setString(3, f[3].getText().trim());
            s.setString(4, f[4].getText().trim());
            s.setString(5, f[0].getText().trim());

            int result = s.executeUpdate();

            if (result > 0) {
                load.run();
                clear.run();
                msg("Cập nhật khách hàng thành công!");
            } else {
                msg("Không tìm thấy khách hàng cần sửa!");
            }

        } catch (Exception ex) {
            err(ex);
        }
    });

    delete.addActionListener(e -> {
        try (Connection c = DB.getConnection();
             PreparedStatement s = c.prepareStatement(
                 "DELETE FROM KhachHang WHERE MaKH = ?")) {

            s.setString(1, f[0].getText().trim());
            s.executeUpdate();

            load.run();
            clear.run();
            msg("Đã xóa khách hàng!");

        } catch (Exception ex) {
            err(ex);
        }
    });

    reload.addActionListener(e -> {
        clear.run();
        load.run();
    });

    load.run();

    return p;
}


    private JPanel invoicePanel() {
        JPanel p=new JPanel(new BorderLayout(8,8));
        JPanel form=new JPanel(new GridLayout(0,2,8,8));form.setBorder(BorderFactory.createTitledBorder("Lập hóa đơn"));
        JTextField maHD=new JTextField(),maKH=new JTextField(),maNV=new JTextField(),maSP=new JTextField(),soLuong=new JTextField(),donGia=new JTextField();
        addField(form,"Mã hóa đơn",maHD);addField(form,"Mã khách hàng",maKH);addField(form,"Mã nhân viên",maNV);
        addField(form,"Mã sản phẩn",maSP);addField(form,"Số lượng",soLuong);addField(form,"Đơn giá",donGia);
        JButton create=new JButton("Tạo hóa đơn và thêm sản phẩm");
        form.add(new JLabel(""));form.add(create);p.add(form,BorderLayout.NORTH);
        JTable table=new JTable();p.add(new JScrollPane(table),BorderLayout.CENTER);
        JLabel hint=new JLabel("Nhập mã KH, NV, SP đã tồn tại. Mọi hóa đơn được tạo kèm một dòng chi tiết.");
        p.add(hint,BorderLayout.SOUTH);
        create.addActionListener(e->{
            String id=maHD.getText().trim();
            try(Connection c=DB.getConnection()){
                c.setAutoCommit(false);
                try(PreparedStatement h=c.prepareStatement("INSERT INTO HoaDon(MaHD,MaKH,MaNV) VALUES(?,?,?)");
                    PreparedStatement detail=c.prepareStatement("INSERT INTO ChiTietHoaDon(MaHD,MaSP,SoLuong,DonGia) VALUES(?,?,?,?)");
                    PreparedStatement stock=c.prepareStatement("UPDATE SanPham SET SoLuongTon=SoLuongTon-? WHERE MaSP=? AND SoLuongTon>=?")){
                    h.setString(1,id);h.setString(2,maKH.getText().trim());h.setString(3,maNV.getText().trim());h.executeUpdate();
                    int qty=Integer.parseInt(soLuong.getText().trim());
                    stock.setInt(1,qty);stock.setString(2,maSP.getText().trim());stock.setInt(3,qty);
                    if(stock.executeUpdate()==0)throw new SQLException("Sản phẩm không tồn tại hoặc không còn hàng tồn");
                    detail.setString(1,id);detail.setString(2,maSP.getText().trim());detail.setInt(3,qty);detail.setBigDecimal(4,new java.math.BigDecimal(donGia.getText().trim()));detail.executeUpdate();
                    c.commit();msg("Tạo hóa đơn thành công");load(table,"SELECT * FROM vw_DoanhThuHoaDon",new String[]{"Mã HD","Ngày lập","Tên KH","Tên NV","Tổng tiền"});
                }catch(Exception ex){c.rollback();throw ex;}
            }catch(Exception ex){err(ex);}
        });
        load(table,"SELECT * FROM vw_DoanhThuHoaDon",new String[]{"Mã HD","Ngày lập","Tên KH","Tên NV","Tổng tiền"});
        return p;
    }

    private JPanel revenuePanel() {
        JPanel p=new JPanel(new BorderLayout()); JTable table=new JTable();
        JButton refresh=new JButton("Cập nhật thống kê"); JLabel total=new JLabel("Tổng doanh thu: ");
        JPanel top=new JPanel(new FlowLayout(FlowLayout.LEFT));top.add(refresh);top.add(total);p.add(top,BorderLayout.NORTH);p.add(new JScrollPane(table),BorderLayout.CENTER);
        Runnable load=()->{load(table,"SELECT * FROM vw_DoanhThuHoaDon",new String[]{"Mã HD","Ngày lập","Tên KH","Tên NV","Tổng tiền"});
            try(Connection c=DB.getConnection();Statement s=c.createStatement();ResultSet r=s.executeQuery("SELECT COALESCE(SUM(ThanhTien),0) FROM ChiTietHoaDon")){if(r.next())total.setText("Tổng doanh thu: "+r.getBigDecimal(1));}catch(Exception ex){err(ex);}};
        refresh.addActionListener(e->load.run());load.run();return p;
    }

    private JPanel basePanel(JTable table,String[] labels,JTextField[] fields){
        JPanel p=new JPanel(new BorderLayout(8,8));JPanel form=new JPanel(new GridLayout(0,4,6,6));form.setBorder(BorderFactory.createTitledBorder("Thông tin"));
        for(int i=0;i<labels.length;i++){form.add(new JLabel(labels[i]));form.add(fields[i]);}
        p.add(form,BorderLayout.NORTH);p.add(new JScrollPane(table),BorderLayout.CENTER);return p;
    }
    private JTextField[] fields(int n){JTextField[] a=new JTextField[n];for(int i=0;i<n;i++)a[i]=new JTextField(14);return a;}
    private JPanel actions(JButton... buttons){JPanel p=new JPanel();for(JButton b:buttons)p.add(b);return p;}
    private void addField(JPanel p,String label,JTextField f){p.add(new JLabel(label));p.add(f);}
    private void load(JTable t,String sql,String[] cols){try(Connection c=DB.getConnection();Statement s=c.createStatement();ResultSet r=s.executeQuery(sql)){
        DefaultTableModel m=new DefaultTableModel(cols,0){public boolean isCellEditable(int row,int col){return false;}};
        while(r.next()){Vector<Object> v=new Vector<>();for(int i=1;i<=cols.length;i++)v.add(r.getObject(i));m.addRow(v);}t.setModel(m);
    }catch(Exception ex){err(ex);}}
    private void runSql(String sql,JTextField[] f,Runnable reload){try(Connection c=DB.getConnection();PreparedStatement s=c.prepareStatement(sql)){
        s.setString(1,f[0].getText().trim());s.setString(2,f[1].getText().trim());s.setString(3,f[2].getText().trim());
        s.setBigDecimal(4,new java.math.BigDecimal(f[3].getText().trim()));s.setInt(5,Integer.parseInt(f[4].getText().trim()));
        s.executeUpdate();reload.run();msg("Thao tác thành công");
    }catch(Exception ex){err(ex);}}
    private void msg(String s){JOptionPane.showMessageDialog(this,s);}
    private void err(Exception e) {
    e.printStackTrace();

    JOptionPane.showMessageDialog(
        this,
        e.getMessage(),
        "Lỗi",
        JOptionPane.ERROR_MESSAGE
    );
}
}
