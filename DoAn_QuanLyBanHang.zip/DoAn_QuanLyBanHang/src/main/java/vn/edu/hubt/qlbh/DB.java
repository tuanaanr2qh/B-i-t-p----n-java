
package vn.edu.hubt.qlbh;

import java.sql.Connection;
import java.sql.DriverManager;

public class DB {

    private static final String URL =
        "jdbc:sqlserver://localhost:1433;"
        + "databaseName=QuanLyBanHang;"
        + "encrypt=true;"
        + "trustServerCertificate=true";

    private static final String USER = "QuanLyBanHang";
    private static final String PASSWORD = "123456";

    public static Connection getConnection() throws Exception {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
