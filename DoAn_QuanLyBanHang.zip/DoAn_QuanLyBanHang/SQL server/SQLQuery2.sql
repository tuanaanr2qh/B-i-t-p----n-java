USE master;
GO

IF DB_ID('QuanLyBanHang') IS NULL
BEGIN
    CREATE DATABASE QuanLyBanHang;
END
GO

-- BUOC 2: TAO TAI KHOAN DANG NHAP
IF NOT EXISTS (
    SELECT 1 FROM sys.server_principals
    WHERE name = 'QuanLyBanHang'
)
BEGIN
    CREATE LOGIN QuanLyBanHang
    WITH PASSWORD = '123456';
END
GO

-- BUOC 3: TAO USER TRONG DATABASE
USE QuanLyBanHang;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.database_principals
    WHERE name = 'QuanLyBanHang'
)
BEGIN
    CREATE USER QuanLyBanHang
    FOR LOGIN QuanLyBanHang;
END
GO

-- BUOC 4: CAP QUYEN QUAN LY DATABASE
ALTER ROLE db_owner
ADD MEMBER QuanLyBanHang;
GO