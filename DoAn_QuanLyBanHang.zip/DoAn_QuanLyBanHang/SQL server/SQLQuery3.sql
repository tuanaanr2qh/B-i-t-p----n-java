
USE master;
GO

-- Tao tai khoan neu chua co, neu da co thi dat lai mat khau
IF SUSER_ID('QuanLyBanHang') IS NULL
BEGIN
    CREATE LOGIN QuanLyBanHang
    WITH PASSWORD = '123456',
    CHECK_POLICY = OFF;
END
ELSE
BEGIN
    ALTER LOGIN QuanLyBanHang
    WITH PASSWORD = '123456',
    CHECK_POLICY = OFF;
END
GO

-- Bat tai khoan
ALTER LOGIN QuanLyBanHang ENABLE;
GO

-- Dat database mac dinh
ALTER LOGIN QuanLyBanHang
WITH DEFAULT_DATABASE = master;
GO

-- Gan tai khoan vao database
USE QuanLyBanHang;
GO

IF DATABASE_PRINCIPAL_ID('QuanLyBanHang') IS NULL
BEGIN
    CREATE USER QuanLyBanHang
    FOR LOGIN QuanLyBanHang;
END
GO

-- Cap quyen
ALTER ROLE db_owner
ADD MEMBER QuanLyBanHang;
GO

-- Kiem tra tai khoan
SELECT name, is_disabled, default_database_name
FROM sys.sql_logins
WHERE name = 'QuanLyBanHang';
GO
