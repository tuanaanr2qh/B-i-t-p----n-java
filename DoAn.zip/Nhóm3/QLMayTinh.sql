﻿USE master;
GO

IF DB_ID(N'QLMayTinh') IS NULL
BEGIN
    CREATE DATABASE QLMayTinh;
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'QuanLyBanHang')
BEGIN
    CREATE LOGIN QuanLyBanHang
    WITH PASSWORD = N'123456',
         CHECK_POLICY = OFF,
         CHECK_EXPIRATION = OFF;
END;
GO

USE QLMayTinh;
GO

IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'QuanLyBanHang')
BEGIN
    CREATE USER QuanLyBanHang FOR LOGIN QuanLyBanHang;
END;
GO

ALTER ROLE db_datareader ADD MEMBER QuanLyBanHang;
ALTER ROLE db_datawriter ADD MEMBER QuanLyBanHang;
GO

IF OBJECT_ID(N'dbo.LoaiMay', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.LoaiMay
    (
        MaLoai INT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_LoaiMay PRIMARY KEY,
        TenLoai NVARCHAR(100) NOT NULL
            CONSTRAINT UQ_LoaiMay_TenLoai UNIQUE
    );
END;
GO

IF OBJECT_ID(N'dbo.SanPham', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.SanPham
    (
        MaSP INT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_SanPham PRIMARY KEY,
        TenSP NVARCHAR(200) NOT NULL,
        MaLoai INT NULL,
        Hang NVARCHAR(100) NOT NULL,
        CPU NVARCHAR(150) NULL,
        RAM NVARCHAR(100) NULL,
        ODia NVARCHAR(150) NULL,
        GPU NVARCHAR(150) NULL,
        ManHinh NVARCHAR(100) NULL,
        BaoHanh INT NOT NULL
            CONSTRAINT DF_SanPham_BaoHanh DEFAULT (12),
        DonGia DECIMAL(18,2) NOT NULL,
        SoLuong INT NOT NULL
            CONSTRAINT DF_SanPham_SoLuong DEFAULT (0),

        CONSTRAINT FK_SanPham_LoaiMay
            FOREIGN KEY (MaLoai) REFERENCES dbo.LoaiMay(MaLoai),
        CONSTRAINT CK_SanPham_BaoHanh CHECK (BaoHanh >= 0),
        CONSTRAINT CK_SanPham_DonGia CHECK (DonGia >= 0),
        CONSTRAINT CK_SanPham_SoLuong CHECK (SoLuong >= 0)
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.LoaiMay WHERE TenLoai = N'Laptop')
    INSERT dbo.LoaiMay(TenLoai) VALUES (N'Laptop');

IF NOT EXISTS (SELECT 1 FROM dbo.LoaiMay WHERE TenLoai = N'PC')
    INSERT dbo.LoaiMay(TenLoai) VALUES (N'PC');

IF NOT EXISTS (SELECT 1 FROM dbo.LoaiMay WHERE TenLoai = N'Màn hình')
    INSERT dbo.LoaiMay(TenLoai) VALUES (N'Màn hình');

IF NOT EXISTS (SELECT 1 FROM dbo.LoaiMay WHERE TenLoai = N'Phụ kiện')
    INSERT dbo.LoaiMay(TenLoai) VALUES (N'Phụ kiện');
GO

IF NOT EXISTS (SELECT 1 FROM dbo.SanPham)
BEGIN
    INSERT dbo.SanPham
        (TenSP, MaLoai, Hang, CPU, RAM, ODia, GPU, ManHinh, BaoHanh, DonGia, SoLuong)
    SELECT N'Laptop ASUS Vivobook 15',
           (SELECT MaLoai FROM dbo.LoaiMay WHERE TenLoai = N'Laptop'),
           N'ASUS', N'Intel Core i5', N'8GB', N'512GB SSD',
           N'Intel Iris Xe', N'15.6 inch', 24, 14500000, 10
    UNION ALL
    SELECT N'Laptop Lenovo IdeaPad Slim 3',
           (SELECT MaLoai FROM dbo.LoaiMay WHERE TenLoai = N'Laptop'),
           N'Lenovo', N'AMD Ryzen 5', N'16GB', N'512GB SSD',
           N'AMD Radeon', N'15.6 inch', 24, 13900000, 8
    UNION ALL
    SELECT N'Máy tính để bàn Gaming',
           (SELECT MaLoai FROM dbo.LoaiMay WHERE TenLoai = N'PC'),
           N'Custom', N'Intel Core i5', N'16GB', N'1TB SSD',
           N'NVIDIA GeForce RTX', N'Không có', 12, 22000000, 5
    UNION ALL
    SELECT N'Màn hình Dell 24 inch',
           (SELECT MaLoai FROM dbo.LoaiMay WHERE TenLoai = N'Màn hình'),
           N'Dell', NULL, NULL, NULL, NULL, N'24 inch', 12, 3200000, 15
    UNION ALL
    SELECT N'Chuột Logitech không dây',
           (SELECT MaLoai FROM dbo.LoaiMay WHERE TenLoai = N'Phụ kiện'),
           N'Logitech', NULL, NULL, NULL, NULL, NULL, 12, 350000, 30;
END;
GO

SELECT * FROM dbo.LoaiMay ORDER BY MaLoai;
SELECT p.MaSP, p.TenSP, l.TenLoai, p.Hang, p.CPU, p.RAM,
       p.ODia, p.GPU, p.ManHinh, p.BaoHanh, p.DonGia, p.SoLuong
FROM dbo.SanPham AS p
LEFT JOIN dbo.LoaiMay AS l ON p.MaLoai = l.MaLoai
ORDER BY p.MaSP;
GO
