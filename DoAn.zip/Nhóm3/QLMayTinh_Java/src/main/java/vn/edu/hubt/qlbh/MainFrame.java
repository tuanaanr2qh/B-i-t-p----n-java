package vn.edu.hubt.qlbh;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class MainFrame extends JFrame {
    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"Mã", "Tên máy / sản phẩm", "Loại", "Hãng", "CPU", "RAM", "Ổ đĩa", "GPU", "Màn hình", "Bảo hành (tháng)", "Đơn giá", "Tồn kho"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JTextField search = new JTextField(22);

    public MainFrame() {
        setTitle("QUẢN LÝ CỬA HÀNG MÁY TÍNH");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1180, 650);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(8, 8));
        setJMenuBar(createMenuBar());

        JLabel heading = new JLabel("QUẢN LÝ BÁN MÁY TÍNH - LAPTOP & LINH KIỆN", SwingConstants.CENTER);
        heading.setFont(new Font("Arial", Font.BOLD, 22));
        heading.setBorder(BorderFactory.createEmptyBorder(12, 8, 12, 8));
        add(heading, BorderLayout.NORTH);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.setRowHeight(24);
        add(new JScrollPane(table), BorderLayout.CENTER);
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton refresh = new JButton("Tải danh sách");
        JButton add = new JButton("Thêm sản phẩm");
        JButton delete = new JButton("Xóa sản phẩm chọn");
        JButton find = new JButton("Tìm kiếm");
        controls.add(new JLabel("Tên / hãng:")); controls.add(search);
        controls.add(find); controls.add(refresh); controls.add(add); controls.add(delete);
        add(controls, BorderLayout.SOUTH);
        refresh.addActionListener(e -> loadProducts(""));
        find.addActionListener(e -> loadProducts(search.getText().trim()));
        search.addActionListener(e -> loadProducts(search.getText().trim()));
        add.addActionListener(e -> addProductDialog());
        delete.addActionListener(e -> deleteSelected());
        loadProducts("");
    }


    // Thanh menu nằm ở góc trên bên trái cửa sổ.
    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu loginMenu = new JMenu("Đăng nhập");
        JMenuItem loginItem = new JMenuItem("Mở giao diện đăng nhập");
        loginItem.addActionListener(e -> showLoginDialog());
        loginMenu.add(loginItem);

        JMenu supportMenu = new JMenu("Hỗ trợ");
        JMenuItem guideItem = new JMenuItem("Hướng dẫn sử dụng");
        guideItem.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "HƯỚNG DẪN SỬ DỤNG\n\n" +
                "1. Nhấn Tải danh sách để xem sản phẩm.\n" +
                "2. Nhập tên hoặc hãng rồi nhấn Tìm kiếm.\n" +
                "3. Nhấn Thêm sản phẩm để thêm mặt hàng mới.\n" +
                "4. Chọn một dòng rồi nhấn Xóa sản phẩm chọn để xóa.\n\n" +
                "Nếu gặp lỗi kết nối, hãy kiểm tra SQL Server và file db.properties.",
                "Hỗ trợ", JOptionPane.INFORMATION_MESSAGE));
        supportMenu.add(guideItem);

        JMenu contactMenu = new JMenu("Liên hệ");
        JMenuItem contactItem = new JMenuItem("Thông tin liên hệ");
        contactItem.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "LIÊN HỆ HỖ TRỢ\n\n" +
                "Ứng dụng: Quản lý cửa hàng máy tính\n" +
                "Email: support@example.com\n" +
                "Điện thoại: 0123 456 789\n\n" +
                "Lưu ý: Thay email và số điện thoại mẫu bằng thông tin thật của bạn.",
                "Liên hệ", JOptionPane.INFORMATION_MESSAGE));
        contactMenu.add(contactItem);

        JMenu aboutMenu = new JMenu("Giới thiệu");
        JMenuItem aboutItem = new JMenuItem("Về phần mềm");
        aboutItem.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "QUẢN LÝ CỬA HÀNG MÁY TÍNH\n\n" +
                "Phần mềm hỗ trợ quản lý sản phẩm máy tính, laptop và linh kiện.\n" +
                "Các chức năng: xem danh sách, tìm kiếm, thêm và xóa sản phẩm.\n\n" +
                "Phiên bản: 1.0", "Giới thiệu", JOptionPane.INFORMATION_MESSAGE));
        aboutMenu.add(aboutItem);

        menuBar.add(loginMenu);
        menuBar.add(supportMenu);
        menuBar.add(contactMenu);
        menuBar.add(aboutMenu);
        return menuBar;
    }

    // Form đăng nhập giao diện mẫu. Tài khoản demo: admin / 123456.
    private void showLoginDialog() {
        JTextField username = new JTextField(18);
        JPasswordField password = new JPasswordField(18);
        JPanel panel = new JPanel(new GridLayout(0, 2, 8, 8));
        panel.add(new JLabel("Tên đăng nhập:"));
        panel.add(username);
        panel.add(new JLabel("Mật khẩu:"));
        panel.add(password);

        int result = JOptionPane.showConfirmDialog(this, panel,
                "ĐĂNG NHẬP HỆ THỐNG", JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;

        String user = username.getText().trim();
        String pass = new String(password.getPassword());
        if ("QuanLyBanHang".equals(user) && "123456".equals(pass)) {
            JOptionPane.showMessageDialog(this, "Đăng nhập thành công! Xin chào " + user + ".",
                    "Đăng nhập", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Tên đăng nhập hoặc mật khẩu không đúng.",
                    "Đăng nhập thất bại", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadProducts(String keyword) {
        model.setRowCount(0);
        String sql = "SELECT p.MaSP,p.TenSP,ISNULL(l.TenLoai,N''),p.Hang,ISNULL(p.CPU,N''),ISNULL(p.RAM,N''),ISNULL(p.ODia,N''),ISNULL(p.GPU,N''),ISNULL(p.ManHinh,N''),p.BaoHanh,p.DonGia,p.SoLuong " +
                "FROM dbo.SanPham p LEFT JOIN dbo.LoaiMay l ON p.MaLoai=l.MaLoai " +
                "WHERE p.TenSP LIKE ? OR p.Hang LIKE ? ORDER BY p.MaSP";
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            String k = "%" + keyword + "%"; ps.setString(1, k); ps.setString(2, k);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) {
                Object[] row = new Object[12]; for (int i=1;i<=12;i++) row[i-1]=rs.getObject(i); model.addRow(row);
            }}
        } catch (Exception ex) { showError("Không tải được sản phẩm.\n" + ex.getMessage()); }
    }

    private void addProductDialog() {
        JTextField name = new JTextField(); JTextField type = new JTextField("Laptop"); JTextField brand = new JTextField();
        JTextField cpu = new JTextField(); JTextField ram = new JTextField(); JTextField disk = new JTextField();
        JTextField gpu = new JTextField(); JTextField screen = new JTextField(); JTextField warranty = new JTextField("12");
        JTextField price = new JTextField(); JTextField stock = new JTextField("0");
        JPanel form = new JPanel(new GridLayout(0,2,5,5));
        addField(form,"Tên sản phẩm *",name); addField(form,"Loại (Laptop/PC/Màn hình/Phụ kiện)",type);
        addField(form,"Hãng",brand); addField(form,"CPU",cpu); addField(form,"RAM",ram); addField(form,"Ổ đĩa",disk);
        addField(form,"GPU",gpu); addField(form,"Màn hình",screen); addField(form,"Bảo hành tháng",warranty);
        addField(form,"Đơn giá *",price); addField(form,"Số lượng *",stock);
        int result = JOptionPane.showConfirmDialog(this, form, "Thêm sản phẩm máy tính", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;
        try {
            if(name.getText().trim().isEmpty() || brand.getText().trim().isEmpty()) throw new IllegalArgumentException("Tên sản phẩm và hãng không được trống.");
            int w = Integer.parseInt(warranty.getText().trim()); int qty = Integer.parseInt(stock.getText().trim());
            double p = Double.parseDouble(price.getText().trim());
            if(w<0 || qty<0 || p<0) throw new IllegalArgumentException("Bảo hành, tồn kho, giá phải >= 0.");
            String sql = "INSERT dbo.SanPham(TenSP,MaLoai,Hang,CPU,RAM,ODia,GPU,ManHinh,BaoHanh,DonGia,SoLuong) " +
                "VALUES(?,(SELECT TOP 1 MaLoai FROM dbo.LoaiMay WHERE TenLoai=?),?,?,?,?,?,?,?,?,?)";
            try(Connection c=DB.getConnection(); PreparedStatement ps=c.prepareStatement(sql)) {
                ps.setString(1,name.getText().trim()); ps.setString(2,type.getText().trim()); ps.setString(3,brand.getText().trim());
                ps.setString(4,emptyToNull(cpu.getText())); ps.setString(5,emptyToNull(ram.getText())); ps.setString(6,emptyToNull(disk.getText()));
                ps.setString(7,emptyToNull(gpu.getText())); ps.setString(8,emptyToNull(screen.getText())); ps.setInt(9,w);
                ps.setDouble(10,p); ps.setInt(11,qty); ps.executeUpdate();
            }
            loadProducts(search.getText().trim()); JOptionPane.showMessageDialog(this,"Đã thêm sản phẩm!");
        } catch(Exception ex) { showError("Không thêm được. Kiểm tra loại máy đã có trong bảng LoaiMay và dữ liệu nhập.\n"+ex.getMessage()); }
    }
    private static String emptyToNull(String s) { return s.trim().isEmpty()?null:s.trim(); }
    private static void addField(JPanel p,String label,JTextField field){p.add(new JLabel(label));p.add(field);}
    private void deleteSelected() {
        int row=table.getSelectedRow(); if(row<0){JOptionPane.showMessageDialog(this,"Chọn một dòng sản phẩm trước.");return;}
        int id=(int)model.getValueAt(row,0);
        if(JOptionPane.showConfirmDialog(this,"Xóa sản phẩm mã "+id+"?","Xác nhận",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;
        try(Connection c=DB.getConnection();PreparedStatement ps=c.prepareStatement("DELETE FROM dbo.SanPham WHERE MaSP=?")){
            ps.setInt(1,id);ps.executeUpdate();loadProducts(search.getText().trim());
        }catch(Exception ex){showError("Không xóa được (có thể sản phẩm đã nằm trong hóa đơn).\n"+ex.getMessage());}
    }
    private void showError(String message){JOptionPane.showMessageDialog(this,message,"Lỗi",JOptionPane.ERROR_MESSAGE);}
}
