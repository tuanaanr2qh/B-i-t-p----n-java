package vn.edu.hubt.qlbh;

import java.sql.Connection;
import java.sql.DriverManager;

public final class DB {
    private DB() {}

    // SQL Server Express theo cau hinh db.properties trong project.
    private static final String URL =
            "jdbc:sqlserver://localhost;"
            + "instanceName=SQLEXPRESS;"
            + "databaseName=QLMayTinh;"
            + "encrypt=true;"
            + "trustServerCertificate=true;";

    private static final String USER = "QuanLyBanHang";
    private static final String PASSWORD = "123456";

    public static Connection getConnection() throws Exception {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
