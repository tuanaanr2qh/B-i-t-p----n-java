package vn.edu.hubt.qlbh;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class LoginFrame extends JFrame {
    private final JTextField username = new JTextField(20);
    private final JPasswordField password = new JPasswordField(20);

    public LoginFrame() {
        setTitle("Đăng nhập - Quản lý cửa hàng máy tính");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(480, 360);
        setResizable(false);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(new Color(245, 247, 250));

        JPanel header = new JPanel();
        header.setBackground(new Color(29, 78, 137));
        header.setBorder(new EmptyBorder(24, 15, 24, 15));
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("QUẢN LÝ CỬA HÀNG MÁY TÍNH");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel("LAPTOP & LINH KIỆN");
        subtitle.setForeground(new Color(225, 235, 248));
        subtitle.setFont(new Font("Arial", Font.PLAIN, 13));
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        header.add(title);
        header.add(Box.createVerticalStrut(8));
        header.add(subtitle);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(new EmptyBorder(22, 35, 18, 35));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(7, 5, 7, 5);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        JLabel formTitle = new JLabel("ĐĂNG NHẬP HỆ THỐNG", SwingConstants.CENTER);
        formTitle.setFont(new Font("Arial", Font.BOLD, 17));
        form.add(formTitle, c);

        c.gridwidth = 1; c.gridy++;
        c.gridx = 0; c.weightx = 0;
        form.add(new JLabel("Tên đăng nhập:"), c);
        c.gridx = 1; c.weightx = 1;
        username.setFont(new Font("Arial", Font.PLAIN, 14));
        form.add(username, c);

        c.gridy++; c.gridx = 0; c.weightx = 0;
        form.add(new JLabel("Mật khẩu:"), c);
        c.gridx = 1; c.weightx = 1;
        password.setFont(new Font("Arial", Font.PLAIN, 14));
        form.add(password, c);


        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 12));
        buttons.setBackground(Color.WHITE);
        JButton login = new JButton("Đăng nhập");
        login.setBackground(new Color(29, 78, 137));
        login.setForeground(Color.WHITE);
        login.setFocusPainted(false);
        JButton exit = new JButton("Thoát");
        buttons.add(login);
        buttons.add(exit);

        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setBackground(Color.WHITE);
        bottom.add(buttons, BorderLayout.CENTER);

        root.add(header, BorderLayout.NORTH);
        root.add(form, BorderLayout.CENTER);
        root.add(bottom, BorderLayout.SOUTH);
        setContentPane(root);

        login.addActionListener(e -> doLogin());
        password.addActionListener(e -> doLogin());
        exit.addActionListener(e -> System.exit(0));
        getRootPane().setDefaultButton(login);
    }

    private void doLogin() {
        String user = username.getText().trim();
        String pass = new String(password.getPassword());
        if ("QuanLyBanHang".equals(user) && "123456".equals(pass)) {
            JOptionPane.showMessageDialog(this, "Đăng nhập thành công!", "Thông báo",
                    JOptionPane.INFORMATION_MESSAGE);
            dispose();
            SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
        } else {
            JOptionPane.showMessageDialog(this, "Tên đăng nhập hoặc mật khẩu không đúng.",
                    "Đăng nhập thất bại", JOptionPane.ERROR_MESSAGE);
            password.setText("");
            password.requestFocus();
        }
    }
}
