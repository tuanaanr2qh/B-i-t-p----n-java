package vn.edu.hubt.qlbh;

import java.sql.Connection;
import java.sql.DriverManager;

public final class DB {

    private DB() {
    }

    private static final String URL =
            "jdbc:sqlserver://localhost:1433;"
            + "databaseName=master;"
            + "encrypt=true;"
            + "trustServerCertificate=true;"
            + "sslProtocol=TLSv1;";

    private static final String USER = "QuanLyBanHang";
    private static final String PASSWORD = "123456";

    public static Connection getConnection() throws Exception {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}